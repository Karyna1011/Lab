# XML Parser
## Lab #3 on OOP
Author: Syvokobylskaya Ira, K-25
