﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    public class MatchInfo
    {
        public string[] ProgressStages { get; set; }
        public string[] Implementers { get; set; }
        public Todo[] TodosList { get; set; }
    }
}
